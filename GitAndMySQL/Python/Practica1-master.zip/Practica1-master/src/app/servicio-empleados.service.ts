import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ServicioEmpleadosService {
  constructor() {}

  showMessage(menssage: string) {
    alert(menssage);
  }
}
