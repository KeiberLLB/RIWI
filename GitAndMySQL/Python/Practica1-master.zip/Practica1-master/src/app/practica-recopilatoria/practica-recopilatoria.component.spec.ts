import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PracticaRecopilatoriaComponent } from './practica-recopilatoria.component';

describe('PracticaRecopilatoriaComponent', () => {
  let component: PracticaRecopilatoriaComponent;
  let fixture: ComponentFixture<PracticaRecopilatoriaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PracticaRecopilatoriaComponent]
    });
    fixture = TestBed.createComponent(PracticaRecopilatoriaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
