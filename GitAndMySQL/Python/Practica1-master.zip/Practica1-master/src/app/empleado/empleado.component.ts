import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-empleado',
  templateUrl: './empleado.component.html',
  styleUrls: ['./empleado.component.css']
})
export class EmpleadoComponent  implements OnInit{
 usuarioRegistrado=false;
 textoRegistro="No hay usuario registrado";
 variable="2";

 getRegistroUsuario(){
  this.usuarioRegistrado=false;
 }
 setUsuarioRegistrado(event:Event){
  if ((<HTMLInputElement>event.target).value=="1") {
    alert("No hay usuario registrado");
    this.variable="2";
  } else {
    alert("El usuario se acaba de registrar");
    this.variable="1";
  }
 }


 ngOnInit(): void {
     
 }

}
