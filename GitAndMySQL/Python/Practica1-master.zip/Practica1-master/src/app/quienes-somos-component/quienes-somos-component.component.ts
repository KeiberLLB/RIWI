import { Component } from '@angular/core';

@Component({
  selector: 'app-quienes-somos-component',
  templateUrl: './quienes-somos-component.component.html',
  styleUrls: ['./quienes-somos-component.component.css']
})
export class QuienesSomosComponentComponent {

}
