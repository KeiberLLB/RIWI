import { Component } from '@angular/core';

@Component({
  selector: 'app-directiva-if',
  templateUrl: './directiva-if.component.html',
  styleUrls: ['./directiva-if.component.css']
})
export class DirectivaIfComponent {
  title= "Registro de usuarios";
  mensaje="";
  registro=false;
  nombre:string="";
  apellido:string="";
  cargo:string="";
  entradas: any;

  constructor(){
    this.entradas=[
      {titulo:"Python"},
      {titulo:"Java"},
      {titulo:"Angular"},
      {titulo:"C++"},
    ]
  }

  registrarUsuario(){
    this.registro=true;
    this.mensaje="Usuario registrado exitosamente";
  }
}
