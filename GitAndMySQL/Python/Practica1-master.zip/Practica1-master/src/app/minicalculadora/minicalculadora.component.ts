import { Component } from '@angular/core';

@Component({
  selector: 'app-minicalculadora',
  templateUrl: './minicalculadora.component.html',
  styleUrls: ['./minicalculadora.component.css']
})
export class MinicalculadoraComponent {
  title = 'Mini calculadora';

  campo1:number=0;
  campo2:number=0;
  resultado:number=0;

  sumar():void{
    this.resultado= this.campo1 + this.campo2;
  }
  restar():void{
    this.resultado= this.campo1 - this.campo2;
  }
  dividir():void{
    this.resultado= this.campo1 / this.campo2;
  }
  multiplicar():void{
    this.resultado= this.campo1 * this.campo2;
  }
}
