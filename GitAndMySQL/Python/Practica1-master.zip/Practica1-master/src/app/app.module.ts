import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmpleadosComponent } from './empleados/empleados.component';
import { EmpleadoComponent } from './empleado/empleado.component';
import { DirectivaIfComponent } from './directiva-if/directiva-if.component';
import { FormsModule } from '@angular/forms';
import { PracticaRecopilatoriaComponent } from './practica-recopilatoria/practica-recopilatoria.component';
import { MinicalculadoraComponent } from './minicalculadora/minicalculadora.component';
import { EmpleadoHijoCComponent } from './empleado-hijo-c/empleado-hijo-c.component';
import { CaracteristicasEmpleadoCComponent } from './caracteristicas-empleado-c/caracteristicas-empleado-c.component';
import { ServicioEmpleadosService } from './servicio-empleados.service';
import { EmpleadoService } from './practica-recopilatoria/empleados.service';
import { HomeComponentComponent } from './home-component/home-component.component';
import { ProyectosComponentComponent } from './proyectos-component/proyectos-component.component';
import { QuienesSomosComponentComponent } from './quienes-somos-component/quienes-somos-component.component';
import { ContactoComponentComponent } from './contacto-component/contacto-component.component';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ActualizarComponent } from './actualizar/actualizar.component';
import { ErrorComponent } from './error/error.component';
import { DataService } from './data.service';
import { LoginComponent } from './login/login.component';
import { LoginService } from './login/login.service';

const appRoutes: Routes = [
  { path: '', component: HomeComponentComponent },
  { path: 'proyectos', component: ProyectosComponentComponent },
  { path: 'quienesSomos', component: QuienesSomosComponentComponent },
  { path: 'contacto', component: QuienesSomosComponentComponent },
  //de esta manera se prepara para que la ruta reciba parametros
  { path: 'actualizar/:id', component: ActualizarComponent },
  { path: 'login', component: LoginComponent },
  //con ** se indica que para cualquier ruta no indicada anteriormente se dirija alli
  { path: '**', component: ErrorComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    EmpleadosComponent,
    EmpleadoComponent,
    DirectivaIfComponent,
    PracticaRecopilatoriaComponent,
    MinicalculadoraComponent,
    EmpleadoHijoCComponent,
    CaracteristicasEmpleadoCComponent,
    HomeComponentComponent,
    ProyectosComponentComponent,
    QuienesSomosComponentComponent,
    ContactoComponentComponent,
    ActualizarComponent,
    ErrorComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    RouterModule.forRoot(appRoutes),
    HttpClientModule,
  ],
  providers: [ServicioEmpleadosService, EmpleadoService, DataService,LoginService],
  bootstrap: [AppComponent],
})
export class AppModule {}
