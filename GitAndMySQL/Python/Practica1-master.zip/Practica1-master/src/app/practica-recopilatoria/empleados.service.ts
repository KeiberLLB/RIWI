import { Injectable } from '@angular/core';
import { Empleado } from './empleado.model';
import { ServicioEmpleadosService } from '../servicio-empleados.service';
import { DataService } from '../data.service';
//da enterder que la clase es inyectable
@Injectable()
export class EmpleadoService {
  constructor(
    private serviceAlert: ServicioEmpleadosService,
    private dataSerice: DataService
  ) {}

  setEmploys(myEmploys: Empleado[]) {
    this.empleados=myEmploys;
  }

  getEmploys() {
    return this.dataSerice.uploadEmploy();
  }
  empleados: Empleado[] = [];
  /*
  empleados: Empleado[] = [
    new Empleado('Pedro', 'Ruiz', 'Salesman', 5000),
    new Empleado('Liliana', 'Rodrigues', 'CO', 18000),
    new Empleado('Sebastian', 'Bentacur', 'Manager', 9100)
  ];
*/
  addEmployService(empleado: Empleado) {
    this.serviceAlert.showMessage(
      'El nombre del empleado es ' +
        empleado.nombre +
        ', con sueldo de ' +
        empleado.salario
    );
    this.empleados.push(empleado);
    //con esta linea se guarda la información en la db de firebase
    this.dataSerice.saveEmploy(this.empleados);
  }
  //dejo este elimar, ya que no requiere de indice para eliminar un empleado en especifico, simplemente elimina al ultimo del array
  deleteEmployService() {
    this.empleados.pop();
    this.serviceAlert.showMessage('Se elimino el empleado');
  }

  foundEmploy(indice: number) {
    let empleado: Empleado = this.empleados[indice];
    return empleado;
  }

  updateEmploy(indice: number, empleado: Empleado) {
    let employUpdate = this.empleados[indice];
    employUpdate.nombre = empleado.nombre;
    employUpdate.apellido = empleado.apellido;
    employUpdate.salario = empleado.salario;
    employUpdate.cargo = empleado.cargo;
    //llama al servicio para actualizar en la db
    this.dataSerice.updateEmploy(indice,empleado);
  }

  deleteEmploy(indice: number) {
    //en java para elimiar un elemento de un array se usa splice (No usaremos pop, ya que esto funciona solo para eliminar el ultimo elemento ingresado)
    this.empleados.splice(indice, 1);
    this.dataSerice.deleteEmploy(indice);
    if (this.empleados!=null) this.dataSerice.saveEmploy(this.empleados);
  }
}
