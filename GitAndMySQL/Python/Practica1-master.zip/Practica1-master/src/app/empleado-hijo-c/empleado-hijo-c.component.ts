import { Component, Input, OnInit } from '@angular/core';
import { Empleado } from '../practica-recopilatoria/empleado.model';

@Component({
  selector: 'app-empleado-hijo-c',
  templateUrl: './empleado-hijo-c.component.html',
  styleUrls: ['./empleado-hijo-c.component.css'],
})
export class EmpleadoHijoCComponent implements OnInit {
  @Input() empleadoLista: Empleado;
  @Input() indice: number;

  constructor() {}
  
  ngOnInit(): void {}
    // Esta es la parte donde se crea la lisFta mediante el padre
    arrayCaracteristicas = [''];

    addCaracteristica(newCaracteristicas: string) {
      this.arrayCaracteristicas.push(newCaracteristicas);
    }
}
