def menu():
    print('------------------Menu Principal-------------------')
    print('\n---------------------------------------------------')
    print('\n1.- Registro de datos personales')
    print('\n2.- Registrarproducto al carrito de compras')
    print('\n2.1.- Registrar nuevo producto al carrito de compras')
    print('\n3.- Listar Carrito de Compras')
    print('\n4.- Eliminar producto')
    print('\n5.- Actualizar producto')
    print('\n6.- Total a Pagar')
    print('\n7.- Salir\n')

def listar(lista_productos):

        print('\nlista de productos')

        for indice, producto in enumerate(lista_productos):
            print(indice,'. -', producto['nombre'], 'precio:',producto['precio'],'cantidad', producto['cantidad'],'categoria', producto['categoria'])
   
def registrar_carrito(carrito,lista_productos):
    
    listar(lista_productos)
    if not lista_productos:
        return
    else:
        try:
            indice = int(input('ingrese el indice del producto a registrar: '))
            if(indice <0 or indice > len(carrito)):
                print('el indice no existe')
            else:
                cantd=int(input('Ingrese la cantidad del producto seleccionado'))
                x=lista_productos[indice]
                x['cantidad']=cantd
                carrito.append(x)
            print('se agrego el producto con exito')
        except:
            print('error, valor no valido')
    
def registrar_carrito2(carrito):
    try:
        nombre = input('Ingrese el nombre del producto: ')
        cantidad = input('Ingrese la cantidad del producto: ')
        precio = input('Ingrese el precio del producto: ')
        categoria = input('Ingrese la categoria del producto: ')

        producto = {'nombre': nombre, 'precio': float(precio), 'cantidad': int(cantidad), 'categoria': categoria}
        carrito.append(producto)
        print('se agrego el producto con exito')

    except:
        print('error, valor no valido')     
            
def listar_carrito(carrito):
    
    if not carrito:
        print('no hay productos en el carrito \n')
    else:
    
        print('\nlista de productos')

        for indice, producto in enumerate(carrito):
                print(indice,'. -', producto['nombre'], 'precio:',producto['precio'],'cantidad', producto['cantidad'],'categoria', producto['categoria'])
    
    
def eliminar(carrito):
    listar(carrito)
    try:
        indice = int(input('Ingrese el indice del producto que desea eliminar: '))
        if(indice <0 or indice > len(carrito)):
                print('indice incorrecto')
        else:
            carrito.pop(indice)
            print('Producto Eliminado')
    except:
        print('***error, valor no valido***')

def actualizar(carrito):
    listar(carrito)
    try:
        indice = int(input('Ingrese el indice del producto que desea actualizar:'))
        if(indice <0 or indice > len(carrito)):
            print('indice incorrecto')
        else:
            nombre = input('Ingrese el nuevo nombre del producto: ')
            precio = input('Ingrese el nuevo precio del producto: ')
            cantidad = input('Ingrese la nueva cantidad del producto: ')
            categoria = input('Ingrese la nueva categoria del producto: ')
            
            carrito[indice]['nombre']=nombre
            carrito[indice]['precio']= float(precio)
            carrito[indice]['cantidad']= int(cantidad)
            carrito[indice]['categoria']=categoria
            
            print('\nEl producto fue actualizado con exito.')

    except:
        print('error, valor no valido')
      
    
def main():
    lista_productos=[{'nombre':'Manzana','precio':2500,'cantidad':0,'categoria':'frutas y verduras'},
                     {'nombre':'Platano','precio':1200,'cantidad':0,'categoria':'frutas y verduras'},
                     {'nombre':'Jabon','precio':8200,'cantidad':0,'categoria':'aseo y hogar'},
                     {'nombre':'Desengrasante','precio':14500,'cantidad':0,'categoria':'aseo y hogar'},
                     {'nombre':'Yogurt','precio':4500,'cantidad':0,'categoria':'lacteos'},
                     {'nombre':'Leche','precio':7800,'cantidad':0,'categoria':'lacteos'},
                     {'nombre':'Mantequilla','precio':5000,'cantidad':0,'categoria':'lacteos'},
                     {'nombre':'Pescado','precio':18000,'cantidad':0,'categoria':'carnes'},
                     {'nombre':'Cerdo','precio':25000,'cantidad':0,'categoria':'carnes'},
                     {'nombre':'Res','precio':42000,'cantidad':0,'categoria':'carnes'}]
    
    carrito=[]
    nombre=''
    apellido=''
    did=''
    
    while True:
        
        menu()
        opcion = float(input('Ingrese una opcion: '))
        if opcion == 1:
            nombre = input('Ingresa tu nombre: ').capitalize()
            apellido = input('Ingresa tu apellido: ').capitalize()
            did = int(input('Ingresa tu documentos de indentidad: '))
            print('se agregaron tus datos con exito')
            
        
        elif opcion == 2:
            registrar_carrito(carrito,lista_productos)
        elif opcion == 2.1:
            registrar_carrito2(carrito)
        elif opcion == 3:
            listar_carrito(carrito)
        elif opcion == 4:
            eliminar(carrito)
        elif opcion == 5:
            actualizar(carrito)
        elif opcion == 6:
            total = 0
            for i in carrito:
                total += i['precio'] * i['cantidad']
                
            print(f'{nombre} {apellido}')
            print(f'Documento de identidad: {did}')
            print('RESUMEN DE SU COMPRA')
            listar_carrito(carrito)
            print(f'Valor productos: {total}')    
            print(f'IVA: {total*0.19}')    
            print(f'El total a pagar es: {total*1.19}')
        elif opcion==7:
            print('bye')
            break      
main()