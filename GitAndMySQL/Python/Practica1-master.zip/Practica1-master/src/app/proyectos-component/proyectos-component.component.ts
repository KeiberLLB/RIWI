import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Empleado } from '../practica-recopilatoria/empleado.model';
import { EmpleadoService } from '../practica-recopilatoria/empleados.service';

@Component({
  selector: 'app-proyectos-component',
  templateUrl: './proyectos-component.component.html',
  styleUrls: ['./proyectos-component.component.css'],
})
export class ProyectosComponentComponent implements OnInit {
  cuadroNombre: string = '';
  cuadroApellido: string = '';
  cuadroCargo: string = '';
  cuadroSalario: number = 0;

  constructor(private EmployService:EmpleadoService,private router: Router) {}

  ngOnInit(): void {
    this.empleados=this.EmployService.empleados;
  }

  volverHome() {
    this.router.navigate(['']);
  }

  empleados: Empleado[] = [];

  agregarEmpleado() {
    let miEmpleado = new Empleado(
      this.cuadroNombre,
      this.cuadroApellido,
      this.cuadroCargo,
      this.cuadroSalario
    );
    //ahora agrego el metodo que saca el mensaje del servicio
    this.EmployService.addEmployService(miEmpleado);
    this.router.navigate(['']);
  }
  eliminarEmpleado() {
   this.EmployService.deleteEmployService();
   this.router.navigate(['']);
  }
}
