def menu():
    print('\n-----------------------------')
    print('-------Menu Principal--------')
    print('\n-----------------------------')
    print('\n1.- Calcular Indice de Masa Corporal')
    print('\n2.- Salir\n')
    
def mensaje(nombre, indice_masa_corporal):
    print(f'\n Hola {nombre}, teniendo en cuenta tu peso y altura, el indice de masa corporal es: {indice_masa_corporal:.2f}\n')
    
    
def indice_masa_corporal(nombre,peso,altura ):
    
    while True:
        nombre=input('Ingrese su nombre aquí: ').capitalize()
        peso=float(input('Ingrese su peso aquí: '))
        altura=float(input('Ingrese su altura aquí: '))
        indice_masa_corporal = peso/(altura*altura)
        
        if indice_masa_corporal < 18.5:
            mensaje(nombre,indice_masa_corporal)
            print('Te encuentras bajo de peso')
            break
        elif indice_masa_corporal >= 18.5 and indice_masa_corporal < 24.9:
            mensaje(nombre,indice_masa_corporal)
            print('Te encuentras en el peso ideal')
            break
        elif indice_masa_corporal >= 24.9 and indice_masa_corporal < 29.9:
            mensaje(nombre,indice_masa_corporal)
            print('Te encuentras sobrepeso')
            break
        elif indice_masa_corporal >= 29.9 and indice_masa_corporal < 34.9:
            mensaje(nombre,indice_masa_corporal)
            print('Te encuentras en Obeso grado I')
            break
        elif indice_masa_corporal >= 34.9 and indice_masa_corporal < 39.9:
            mensaje(nombre,indice_masa_corporal)
            print('Te encuentras en Obeso grado II')
            break
        elif indice_masa_corporal >= 39.9 and indice_masa_corporal < 49.9:
            mensaje(nombre,indice_masa_corporal)
            print('Te encuentras en Obeso grado III')
            break
        elif indice_masa_corporal >= 49.9:
            mensaje(nombre,indice_masa_corporal)
            print('Te encuentras en Obeso grado IV')   
            break   
    
def main():
    
    nombre = ''
    peso = 0
    altura = 0
    while True:
        menu()
        opcion = int(input('Ingrese una opcion: '))
        if opcion == 1:
            indice_masa_corporal(nombre,peso,altura)
        elif opcion == 2:
            break
    
main()