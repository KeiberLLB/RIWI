import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-practica-recopilatoria',
  templateUrl: './practica-recopilatoria.component.html',
  styleUrls: ['./practica-recopilatoria.component.css'],
})
export class PracticaRecopilatoriaComponent {
 // Se movio todo lo que tenia aqui para el componente home
}
