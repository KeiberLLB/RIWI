import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Empleado } from '../practica-recopilatoria/empleado.model';
import { EmpleadoService } from '../practica-recopilatoria/empleados.service';

@Component({
  selector: 'app-actualizar',
  templateUrl: './actualizar.component.html',
  styleUrls: ['./actualizar.component.css'],
})
export class ActualizarComponent implements OnInit {
  cuadroNombre: string = '';
  cuadroApellido: string = '';
  cuadroCargo: string = '';
  cuadroSalario: number = 0;
  indice: number;
  accion: number;

  constructor(
    private EmployService: EmpleadoService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.empleados = this.EmployService.empleados;
    this.indice = this.route.snapshot.params['id'];
    let empleado: Empleado = this.EmployService.foundEmploy(this.indice);
    this.cuadroNombre = empleado.nombre;
    this.cuadroApellido = empleado.apellido;
    this.cuadroSalario = empleado.salario;
    this.cuadroCargo = empleado.cargo;
    this.accion = parseInt(this.route.snapshot.queryParams['accion']);
  }

  volverHome() {
    this.router.navigate(['']);
  }

  empleados: Empleado[] = [];
  /*
  actualizarEmpleado() {
    let miEmpleado = new Empleado(
      this.cuadroNombre,
      this.cuadroApellido,
      this.cuadroCargo,
      this.cuadroSalario
    );
    //ahora agrego el metodo que saca el mensaje del servicio
    this.EmployService.updateEmploy(this.indice,miEmpleado);
    this.router.navigate(['']);
  }

  eliminarEmpleado(){
    this.EmployService.deleteEmploy(this.indice);
    this.router.navigate(['']);
  }
  */
  accionEmpleado() {
    if (this.accion == 1) {
      let miEmpleado = new Empleado(
        this.cuadroNombre,
        this.cuadroApellido,
        this.cuadroCargo,
        this.cuadroSalario
      );
      this.EmployService.updateEmploy(this.indice, miEmpleado);
      this.router.navigate(['']);
    } else {
      this.EmployService.deleteEmploy(this.indice);
      this.router.navigate(['']);
    }
  }
}
