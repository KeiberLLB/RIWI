# **Apuntes Primeras clases**
## **Comandos**
Para crear un componente mediante la CLI se escribe el siguiente comando `ng generate component "NombreDelComponente"`. Sin embargo para hacerlo de una forma abreviada se pondria: `ng g c "NombreDelComponente"`

## **Crear componente inline**
Para indicar que el componente inline se le agrega un `-s`, pero si quiero que los template tambien lo sean le agrego `-t`. Por lo tanto el comando completo quedaria asi: `ng g c "NombreDelComponente" -s -t`

### **Crear servicio**
Para la creación de un servicio debemos escribir el siguiente comando (abreviado en este caso) `ng g s nombreDelServicio` 
Para usar el servicio, además de crearlo se debe registar en la aplicación, esto se hace en el archivo app.module.ts, en la parte de provaiders

## **Interpolación**
La interpolación es el usop de variables en un texto, esto permite un facil manejo de palabras (realmente datos), en un archivo html. La interpolacion se da con las llaves, de la siguiente manera {{Variable}}, realizar esto nos permite poder realizar operaciones como normalmente se hace con una variable, ya que lo que se toma dentro de las llaves es una propiedad del componente.  
Por lo tanto, se debe tener en cuenta el caracter de la variable (Public, private o protect).

## **Property Binding**
Es la menera de enlazar dos archivos del proyecto. Primero se crea en en el componente una variable que es la que determinara la accion del html, luego en el html debemos sabernos las propiedades de los diferentes elementos que existen allí, por ejemplo en una caja de chequeo seria el *checked*. Finalmente para poder realizar el biding lo que debemos hacer es poner [propiedad]="variable creada en el componente"; esto en codigo se veria asi:  
`Registrado:<input type="checkbox" id="registro "[checked]="usuarioRegistardo">`        
***usuarioRegistrado:*** Esta es la variable creada en el component que define el estado del cuadro de texto, en este caso puede ser una varible booleana simplemente.

## **Event biding**
Por su traduccion, event biding se entiende como el puente de un evento. Es decir, cuando un usuario realizxa una acción determinada en la pagina, esta responde acorde a esta acción, no solo pasa con eventos del usuario sino también con eventos propios de la pagina.  
En codigo sería lo siguiente:   
`Registrado: <input type="checkbox" id="registro "[checked]="usuarioRegistrado" (click)="setUsuarioRegistrado()"><br/>` 
`{{getRegistroUsuario()}}`  
Esto significa que cada que exista el evento click se ejecutara el evento programadoo en el ts, por lo que la union de evento con template se hace correctamente. 

### **Consideraciones**
Para tener en cuenta el siguiente codigo que se realiza un trabajo con el biding y algo de logica de programacion.  
```
export class EmpleadoComponent  implements OnInit{
 usuarioRegistrado=false;
 textoRegistro="No hay usuario registrado";
 variable="2";

 getRegistroUsuario(){
  this.usuarioRegistrado=false;
 }
 setUsuarioRegistrado(event:Event){
  if ((<HTMLInputElement>event.target).value=="1") {
    alert("No hay usuario registrado");
    this.variable="2";
  } else {
    alert("El usuario se acaba de registrar");
    this.variable="1";
  }
 }  
```
en este condicional se toma las propiedades del evento y se compara, simplemente se modifica para que pueda seguir funcionando para eventos futuros y se cambia el mensaje de alerta en el else.

### **Comunicación entre componentes**
Para realizar la comunicación entre componentes padre e hijo se deben utilizar las etiquetas @Input y @Output.Estas etiquetas se usan en el siguiente sentido:  
Padre ---> Hijo  : Se usa @Input  
Hijo  ---> Padre : Se usa @Output 

### **Routing**
Para esto se va al archivo appmodule.ts y dentro de declaraction se ponen los nuevos modulos (con algunas extensiones del vs esto se hace de manera automatica cuando se crean los componentes).  
Ahora bien, para crear las rutas se crea una constante antes de @ngModule y en este lugar se almacenarán las rutas. Además, debemops importar el RouterModule y indicarle la constante donde estan todas las rutas



 