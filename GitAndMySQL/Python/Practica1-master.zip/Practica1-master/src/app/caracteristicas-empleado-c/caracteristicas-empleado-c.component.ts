import { Component, EventEmitter, Output } from '@angular/core';
import { ServicioEmpleadosService } from '../servicio-empleados.service';

@Component({
  selector: 'app-caracteristicas-empleado-c',
  templateUrl: './caracteristicas-empleado-c.component.html',
  styleUrls: ['./caracteristicas-empleado-c.component.css'],
})
export class CaracteristicasEmpleadoCComponent {
  @Output() newCaracteristicas = new EventEmitter<string>();
  addCaracteristicas(value: string) {
    this.newCaracteristicas.emit(value);
    this.myService.showMessage("Se ha ahregado la caracteristica: "+value);
  }
  constructor(private myService:ServicioEmpleadosService) {}
}
