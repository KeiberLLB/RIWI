def menu():
    print('------------------Menu Principal-------------------')
    print('\n---------------------------------------------------')
    print('\n1.- Registrar paciente')   
    print('\n2.- Actualizar datos paciente')
    print('\n3.- Ver pacientes activos')
    print('\n4.- Ver pacientes inactivos')
    print('\n5.- Listar pacientes\n')
    print('\n6.- Salir\n')

def listar(pacientes):

        print('\nlista de pacientes')

        for indice, paciente in enumerate(pacientes):
            print(indice,'. -', paciente['nombre'], 'dni:',paciente['dni'],'raza', paciente['raza'],'edad', paciente['edad'], 'estado', paciente['estado'], 'diagnostico', paciente['diagnostico'])

def registro_pacientes(pacientes):
    try:
        nombre = input('Ingrese el nombre del paciente: ').capitalize()
        dni = input('Ingrese el DNI del dueño: ')
        raza = input('Ingrese la raza del paciente: ')
        edad = input('Ingrese la edad del paciente: ')
        estado = input('Ingrese si el paciente esta o no en la veterinacia: S/N ').upper()
        diagnostico = input('Ingrese la valoracion del paciente: ').capitalize()
        

        paciente = {'nombre': nombre, 'dni': int(dni), 'raza': raza, 'edad': int(edad), 'estado':estado,'diagnostico':diagnostico}
        pacientes.append(paciente)
        print('se agrego el paciente con exito')

    except:
        print('error, valor no valido')    
        
def actualizar_pacientes(pacientes):
    listar(pacientes)
    try:
        indice = int(input('Ingrese el indice del paciente:'))
        if(indice <0 or indice > len(pacientes)):
            print('indice incorrecto')
        else:
            nombre = input('Ingrese el nombre del paciente: ').capitalize()
            dni = input('Ingrese el DNI del dueño: ')
            raza = input('Ingrese la raza del paciente: ')
            edad = input('Ingrese la edad del paciente: ')
            estado = input('Ingrese si el paciente esta o no en la veterinacia: S/N ').upper()
            diagnostico = input('Ingrese la valoracion del paciente: ').capitalize()
            
            pacientes[indice]['nombre']=nombre
            pacientes[indice]['dni']= int(dni)
            pacientes[indice]['raza']= raza
            pacientes[indice]['edad']= int(edad)
            pacientes[indice]['estado']=estado
            pacientes[indice]['diagnostico']=diagnostico
            
            print('\nEl paciente fue actualizado con exito.')

    except:
        print('error, valor no valido')

def activos(pacientes):
    counter=0
    for i in pacientes:
        for j in i['estado']:
            if j == 'S':
                print(i['nombre'])
                counter+=1
    print(f'el total de pacientes activos es: {counter}')
            
def inactivos(pacientes):
    counter=0
    for i in pacientes:
        for j in i['estado']:
            if j == 'N':
                print(i['nombre'])
                counter+=1
    print(f'el total de pacientes inactivos es: {counter}')

def main(): 
    pacientes = []
    while True:
        opcion =int(input('Ingrese una opcion: ')) 
        if opcion == 1:
            registro_pacientes(pacientes)
        if opcion == 2:
            actualizar_pacientes(pacientes)
        elif opcion == 3:
            activos(pacientes)
        elif opcion == 4:
            inactivos(pacientes)
        elif opcion == 5:
            listar(pacientes)                      
        elif opcion == 6:
            print('bye')
            break
        
main()
