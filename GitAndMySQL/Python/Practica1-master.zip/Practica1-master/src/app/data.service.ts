import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Empleado } from './practica-recopilatoria/empleado.model';
import { LoginService } from './login/login.service';

@Injectable({
  providedIn: 'root',
})
export class DataService {
  constructor(private httpClient: HttpClient, private loginSerice: LoginService) {}

  uploadEmploy() {
    const token=this.loginSerice.getIdToken();
    return this.httpClient.get(
      'https://clientes-9ed1c-default-rtdb.firebaseio.com/datos.json?auth='+token
    );
  }

  saveEmploy(empleados: Empleado[]) {
    this.httpClient
      .put(
        'https://clientes-9ed1c-default-rtdb.firebaseio.com/datos.json',
        empleados
      )
      .subscribe(
        (response) => console.log('Se han guardado los empleados: ' + response),
        (error) => console.log('Error: ' + error)
      );
  }

  updateEmploy(indice: number, empleado: Empleado) {
    let url='https://clientes-9ed1c-default-rtdb.firebaseio.com/datos/'+indice+'.json';
    this.httpClient
      .put(url,empleado)
      .subscribe(
        (response) => console.log('Se ha actualizado el empleado: ' + response),
        (error) => console.log('Error: ' + error)
      );
  }

  deleteEmploy(indice: number) {
    let url='https://clientes-9ed1c-default-rtdb.firebaseio.com/datos/'+indice+'.json';
    this.httpClient
      .delete(url)
      .subscribe(
        (response) => console.log('Se ha eliminado el empleado: ' + response),
        (error) => console.log('Error: ' + error)
      );
  }
}
