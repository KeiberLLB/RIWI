import { Component, OnInit } from '@angular/core';
import { Empleado } from '../practica-recopilatoria/empleado.model';
import { EmpleadoService } from '../practica-recopilatoria/empleados.service';

@Component({
  selector: 'app-home-component',
  templateUrl: './home-component.component.html',
  styleUrls: ['./home-component.component.css'],
})
export class HomeComponentComponent implements OnInit {
  titulo = 'LISTADO DE EMPELADOS';
  cuadroNombre: string = '';
  cuadroApellido: string = '';
  cuadroCargo: string = '';
  cuadroSalario: number = 0;

  //esta es la menera de inyectar el servicio en el componente principal, además hay que agregar el metodo que deseo
  constructor(private employService: EmpleadoService) {
    //esto mismo se puede hacer con OnInit
    //this.empleados=this.EmployService.empleados;
  }

  ngOnInit(): void {
    //this.empleados=this.EmployService.empleados;
    this.employService.getEmploys().subscribe((myEmploys) => {
      console.log(myEmploys);
      //de esta manera hacemos que un objeto simple, almacene un array
      this.empleados = Object.values(myEmploys);
      this.employService.setEmploys(this.empleados);
    });
  }
  empleados: Empleado[] = [];
  /*
  esta parte es necesaria ya que no hay back
  empleados: Empleado[] = [  
    new Empleado('Pedro', 'Ruiz', 'Salesman', 5000),
    new Empleado('Liliana', 'Rodrigues', 'CO', 18000),
    new Empleado('Sebastian', 'Bentacur', 'Manager', 9100),
  ];
  */
  //el array queda vacio para que se pueda almacenar y los otros compoenentes puedan realizar el for con regularidad

  agregarEmpleado() {
    let miEmpleado = new Empleado(
      this.cuadroNombre,
      this.cuadroApellido,
      this.cuadroCargo,
      this.cuadroSalario
    );
    //ahora agrego el metodo que saca el mensaje del servicio
    this.employService.addEmployService(miEmpleado);
  }
  eliminarEmpleado() {
    this.employService.deleteEmployService();
  }
}
