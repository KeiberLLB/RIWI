import { Component, OnInit } from '@angular/core';
import fireBase from 'firebase/compat/app';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {
    fireBase.initializeApp({
      apiKey: 'AIzaSyD1e2IBGx9g_Izv8IjKvZ1NqVf1Vr8Bbi4',
      authDomain: 'clientes-9ed1c.firebaseapp.com',
    });
  }
  title = 'Practica1';
}
